setTimeout(() => {
  if(EnableAnimatedScar == 1) {
    pc.app.on("Map:Loaded", () => {
      setTimeout(() => {
        createWireframe();
        setTimeout(() => {
          loadVideoScript();
        }, 500);
      }, 2000);
    });
    
    function createWireframe() {
      for(i = 0; i < pc.app.root.findByName("Scar").children[0].model.meshInstances.length; i++) {
        pc.app.root.findByName("Scar").children[0].model.meshInstances[i].renderStyle = 1
      }
    }
    
    function loadVideoScript() {
	var scarModel = pc.app.root.findByName("Scar").children[0];
      function videoScar() {
        var t = pc.app,
          n = pc.app.assets
            .getAssetById(29307613)
            .file.url.replace(
              "29307613/1/Scar_Diffuse.jpg",
              "CustomContent/AnimatedSkins/AnimatedScar.mp4"
            ),
          a = new pc.Texture(pc.app.graphicsDevice, {
            format: pc.PIXELFORMAT_R8_G8_B8_A8,
            autoMipmap: !1,
          });
        (a.minFilter = pc.FILTER_LINEAR),
          (a.magFilter = pc.FILTER_LINEAR),
          (a.addressU = pc.ADDRESS_REPEAT),
          (a.addressV = pc.ADDRESS_REPEAT);
        window.i = document.createElement("video");
        return (
          i.addEventListener("canplay", function (e) {
            a.setSource(i);
          }),
          i.setAttribute("webkit-playsinline", "webkit-playsinline"),
          (i.muted = !0),
          (i.volume = 0.2),
          (i.src = n),
          (i.crossOrigin = "anonymous"),
          (i.loop = !0),
          (i.autoplay = 1),
          i.load(),
          i.play(),
          (this.isAnimatedSkin = !0),
          (this.videoTexture = a),
          a,
          (scarModel.model.meshInstances[0].material.diffuseMap = a),
          scarModel.model.meshInstances[0].material.update(),
          setInterval(() => {
            this.videoTexture.upload();
          }, 100)
        );
      }
      videoScar();
    }
  }
}, 1000);