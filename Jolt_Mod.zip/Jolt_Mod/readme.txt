ABOUT JOLT MOD:

This mod is made by Mr.Bowser and Chronosurge 

Chronosurge: Tester and coder
Mr.Bowser: Editor and file manager. 

To install this mod: 

Step 1: Copy Venge Client folder 
Step 2: Go to Document 
Step 3: Paste it there, if ask you to replace, click yes.
Step 4: Open Venge Client and enjoy the mod!