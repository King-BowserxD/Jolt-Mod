How to install this mod:

Step 1: Copy Venge Client folder
Step 2: Go to Documents folder
Step 3: Paste the Venge Client folder
Step 4: Open Venge Client and enjoy!

If you have any feedback, feel free to dm me .kingbowserxd on Discord. Thanks for using it!